import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.BorderLayout;

public class LabelCreator extends JFrame {
    public LabelCreator() {
        super("Label Creator");
        JPanel panel = new JPanel();

        this.add(panel, BorderLayout.CENTER);

        JButton button = new JButton("Add new label");
        button.addActionListener(e -> {
            new LabelCreatorListener(panel);
            this.revalidate();
        });
        this.add(button, BorderLayout.SOUTH);

        this.setSize(200,200);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        new LabelCreator();
    }
}
