import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

public class A29a_main extends JFrame {
    public A29a_main () {
        super("Aufgabe 29a");

        JPanel panelNorth = new JPanel();

        JLabel label = new JLabel("Kontonummer");
        label.setFont(new Font("Arial",Font.PLAIN,20));
        panelNorth.add(label);

        JTextField text = new JTextField(20);
        text.setFont(new Font("Arial",Font.PLAIN,20));
        panelNorth.add(text);

        JPanel panelSouth = new JPanel();
        panelSouth.add(new JButton("Okay"));
        panelSouth.add(new JButton("Abbrechen"));

        panelNorth.setBackground(new Color(222, 222, 222));
        panelSouth.setBackground(new Color(131, 131, 131));
        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        pack();
        setVisible(true);
    }
    public static void main(String[] args) {
        new A29a_main();
    }
}
