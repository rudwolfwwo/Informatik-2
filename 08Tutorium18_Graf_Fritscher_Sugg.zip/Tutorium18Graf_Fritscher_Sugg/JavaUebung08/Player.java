public class Player {
    private String name;
    private Team team;
    public Player(String name, Team team) {
        this.name = name;
        this.team = team;
        setTeam(team);
    }
    public void setTeam(Team team) {
        this.team = team;
        team.addPlayer(this);
    }
    public Team getTeam() {
        return team;
    }
}
