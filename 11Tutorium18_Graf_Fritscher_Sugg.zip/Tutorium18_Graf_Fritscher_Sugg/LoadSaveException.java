//Gehört nicht zur Abgabe, sonst kennt nur Java natürlich keine LoadSaveException...
public class LoadSaveException extends Exception {
    public LoadSaveException (String message, Throwable cause) {
        super(message, cause);
    }
}
