import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.BorderLayout;

public class TitleChanger extends JFrame {
    public TitleChanger () {
        super("TitleChanger");
        this.setSize(350,100);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(2,2));
        for (int i = 1; i <= 4; i++) {
            JButton b = new JButton("Button " + i);
            panel.add(b);
            b.addActionListener(e -> this.setTitle("Title changed by " + b.getActionCommand()));
        }

        this.add(panel,BorderLayout.CENTER);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        new TitleChanger();
    }
}