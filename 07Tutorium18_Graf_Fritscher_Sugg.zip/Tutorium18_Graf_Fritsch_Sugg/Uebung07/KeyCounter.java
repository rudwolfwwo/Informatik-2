import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class KeyCounter extends JFrame {
    int i = 0;
    public KeyCounter() {
        super("KeyCounter: 0");
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_P) {
                    if (e.isShiftDown()) {
                        i = i + 10;
                    } else {
                        i++;
                    }
                    setTitle("KeyCounter: " + i);
                }
            }
        });
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.pack();
    }
    public static void main(String[] args) {
        new KeyCounter();
    }
}
