import java.util.Random;
import java.util.function.Supplier;
import java.util.stream.Stream;


public class Aufgabe22c {
    public static void main (String[] args) {
        Random rdn = new Random();
        Supplier<Character> suppe = () -> (char) ('a' + rdn.nextInt(26));

        Stream <String> woerter = Stream
                .generate(() -> {
                            StringBuilder sb = new StringBuilder();
                            int x = rdn.nextInt(5,11);
                            for (int i = 0; i < x; i++) {
                                sb.append(suppe.get());
                            }
                             return sb.toString();
                            })
                .limit(500);

        System.out.println(woerter.mapToInt(String::length).average().orElseThrow());
    }
}
