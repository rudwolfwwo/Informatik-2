import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class A23_24b_main {
    public static void main (String[] args) {
        Student s1 = new Student("Tom", 1234567);
        System.out.println(s1);
        Scanner input = new Scanner(System.in);
        input.useDelimiter(Pattern.compile("[\\r\\n]+"));
        List<Student> Studenten = new ArrayList<>();
        Studenten.add(s1);

        try {
            String name;
            int nummer;
            while (true) {
                System.out.println("Bitte geben Sie einen Namen ein: ");
                name = input.next();
                Student.check_Name(name);
                System.out.println("Bitte geben Sie die Matrikelnummer von " + name + " ein: ");
                nummer = input.nextInt();

                Student.check_Matrikelnummer(nummer);
                Studenten.add(new Student(name, nummer));

                System.out.println("Alle Studenten in der Liste: ");
                Studenten.forEach(System.out::println);
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Ungueltige Eingabe: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.err.println("Für die Matrikelnummer sind nur Zahlen erlaubt");
        }
    }
}
