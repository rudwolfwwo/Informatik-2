import java.sql.*;

public class BankDB {
    String url, benutzername, passwort;
    
    public void add (BankAccount bankAccount) throws LoadSaveException {
        try (Connection c = DriverManager.getConnection(url, benutzername, passwort)) {
            if (c == null) throw new LoadSaveException("No Connection available", null);
            String befehl = "INSERT INTO BankAccount VALUES (" +
                    bankAccount.getAccountNumber() + "," + bankAccount.getAccountHolderName() + "," +
                    bankAccount.getBalance() + ")";
            Statement s = c.createStatement();
            s.executeUpdate(befehl);
        } catch (SQLException c) {
            throw new LoadSaveException(c.getMessage(),c.getCause());
        }
    }
    
    public void delete (BankAccount bankAccount) throws LoadSaveException {
    	try (Connection c = DriverManager.getConnection(url, benutzername, passwort)) {
            if (c == null) throw new LoadSaveException("No Connection available", null);
            String befehl = "DELETE FROM BankAccount "
            		+ "WHERE accountNumber = '" + bankAccount.getAccountNumber() + "' "
            		+ "AND accountHolderName = '" + bankAccount.getAccountHolderName() + "' "
            		+ "AND balance = " + bankAccount.getBalance();
            Statement s = c.createStatement();
            s.executeUpdate(befehl);
        } catch (SQLException c) {
            throw new LoadSaveException(c.getMessage(),c.getCause());
        }
    }
}
