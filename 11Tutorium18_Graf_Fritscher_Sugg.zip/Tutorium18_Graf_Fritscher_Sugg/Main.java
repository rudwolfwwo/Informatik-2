import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class Main {

    public static void main(String[] args) throws SQLException {
        String url = "jdbc:mysql://educos-srv01.informatik.uni-augsburg.de:3306/theDatabase?useSSL=false";
        String benutzername = "student";
        String passwort = "inFormatik2";

        try (Connection c = DriverManager.getConnection(url, benutzername, passwort)) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            System.out.println(Main.getChoresDone(c,"Andreas"));
            Main.choresDoneBeforeBirthday(c,"Tobias",2022);
        } catch (SQLException | ClassNotFoundException e) {
            e.getStackTrace();
        }
    }
    public static double getChoresDone(Connection connection, String flatmate) {
        try {
            String befehl = "SELECT Chore.timeRequiredHours "
            		+ "FROM Chore, FlatmateChore "
                    + "WHERE FlatmateChore.name = ? "
                    + "AND Chore.chore = FlatmateChore.chore";
            PreparedStatement s = connection.prepareStatement(befehl);
            s.setString(1,flatmate);
            ResultSet r = s.executeQuery();
            double temp = 0;
            while (r.next()) {
                temp += r.getDouble("timeRequiredHours");
            }
            return temp;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }
    }
    public static void choresDoneBeforeBirthday(Connection connection, String flatmate, int year) {
    	try {
            String befehl = "SELECT Chore.chore, FlatmateChore.doneAt,Flatmate.birthday "
            		+ "FROM Chore, FlatmateChore, Flatmate "
                    + "WHERE FlatmateChore.name = ? "
                    + "AND Chore.chore = FlatmateChore.chore "
                    + "AND Flatmate.name = FlatmateChore.name";
            PreparedStatement s = connection.prepareStatement(befehl);
            s.setString(1,flatmate);
            ResultSet r = s.executeQuery();
            while (r.next()) {
            	LocalDate birthday = r.getDate("birthday").toLocalDate().withYear(year);
            	LocalDate doneAt = r.getDate("doneAt").toLocalDate();
            	if (doneAt.isBefore(birthday) && doneAt.isAfter(birthday.minusDays(7))) {
            		System.out.println(r.getString("chore") + "\t" + doneAt);
            	}
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}