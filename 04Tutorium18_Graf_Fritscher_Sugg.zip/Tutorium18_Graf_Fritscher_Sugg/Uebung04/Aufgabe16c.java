import java.time.LocalTime;
import java.util.Random;

public class Aufgabe16c {
    public static void main (String[] args) {
        LocalTime t1 = uhrzeitWuerfeln();
        LocalTime t2 = uhrzeitWuerfeln();

        if (t1.isAfter(t2)) {
            LocalTime hilfsobjekt = t1;
            t1 = t2;
            t2 = hilfsobjekt;
        }
        System.out.println("Die frühere Zeit t1 ist: " + t1 + " Uhr \nDie spätere Zeit t2 ist: " + t2 + " Uhr");

        boolean bol = false;
        while (t1.plusMinutes(15).isAfter(t2)) {
            bol = true;
            LocalTime neu = uhrzeitWuerfeln();
            if (neu.isAfter(t1) && neu.isBefore(t2)) {
                t2 = neu;
                break;
            }
        }
        System.out.println("\nDie Zeit t1 bleibt bei " + t1 + " Uhr \nDie Zeit t2 " +
                (bol ? "erneuert sich auf " : "bleibt bei ") + t2 + " Uhr");
    }
    private static LocalTime uhrzeitWuerfeln() {
        Random rdn = new Random();
        int hour = rdn.nextInt(24);
        int minute = rdn.nextInt(60);
        return LocalTime.of(hour,minute);
    }
}
