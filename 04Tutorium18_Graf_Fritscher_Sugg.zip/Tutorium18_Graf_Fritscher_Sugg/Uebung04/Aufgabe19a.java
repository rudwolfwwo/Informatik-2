import java.util.Arrays;
import java.util.List;
import java.util.function.UnaryOperator;

public class Aufgabe19a {
    public static void main (String[] args) {
        List<String> liste = Arrays.asList(args);
        UnaryOperator<String> converter = String::toUpperCase;
        liste.replaceAll(converter);
        liste.stream().filter(s -> s.charAt(0) != 'A').forEach(System.out::println);
    }
}
