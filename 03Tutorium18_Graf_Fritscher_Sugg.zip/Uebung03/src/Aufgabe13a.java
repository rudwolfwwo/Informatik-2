import java.util.Random;
import static java.util.Arrays.*;

public class Aufgabe13a {
    public static void main (String[] args) {

        int[] arr = new int[10000];
        Random rdn = new Random();
        for (int i = 0; i < arr.length; i++) {
            arr[i] = rdn.nextInt(1,10);
        }

        int[] copy = copyOfRange(arr, 0, arr.length/2);
        sort(copy);
        int[] drittes = new int[5000];
        fill(drittes,1);

        for (int i = 0; i < copy.length; i++) {
            if (!(copy[i] == drittes[i])) {
                System.out.println("Das erste Mal unterscheiden sich beide Listen an " + (i+1) + ". Position");
                break;
            }
        }
    }
}
