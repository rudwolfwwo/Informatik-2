import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Point;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;

public class LinePanel extends JPanel {
    ArrayList<Point> liste = new ArrayList<>();
    Point neu;
    public LinePanel() {
        this.setPreferredSize(new Dimension(300,300));
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                neu = new Point(e.getX(),e.getY());
                liste.add(new Point(e.getX(),e.getY()));
                repaint();
            }
        });
        this.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                neu = new Point(e.getX(),e.getY());
                repaint();
            }
        });
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (!liste.isEmpty()) {
            Point p1 = liste.get(0);
            for (Point p : liste) {
                g.drawLine((int) p1.getX(), (int) p1.getY(),(int) p.getX(), (int) p.getY());
                p1 = p;
            }
            g.drawLine((int) neu.getX(), (int) neu.getY(),
                    (int) liste.get(liste.size() - 1).getX(), (int) liste.get(liste.size() - 1).getY());
        }
    }
}
