import java.util.ArrayList;

public class Team {
    private String name;
    private static ArrayList<String> usedNames;
    private ArrayList<Player> players;
    public Team(String name, ArrayList<Player> players) throws IllegalArgumentException {
        if (usedNames.contains(name)) throw new IllegalArgumentException("Name wird bereits genutzt");
        this.name = name;
        this.players = players;
        usedNames.add(name);
    }
    public void addPlayer(Player player) {
        for (Player p : players) {
            if (p.equals(player)) removePlayer(player);
        }
        players.add(player);
    }
    public void removePlayer(Player player) {
        players.remove(player);
    }

    public boolean equals(Object o) {
        if (o == null || !o.getClass().equals(this.getClass())) return false;
        return ((Team) o).name.equals(name);
    }
}