import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.BorderLayout;

public class A29b_main extends JFrame {
    public A29b_main() {
        super("PIN");
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4,3));
        String[] labels = {"7","8","9","4","5","6","1","2","3","0","Clear","Okay"};
        for (String label : labels) {
            panel.add(new JButton(label));
        }

        this.add(new JPanel().add(new JLabel(" ")),BorderLayout.NORTH);
        this.add(panel);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        pack();
        setVisible(true);
    }
    public static void main(String[] args) {
        new A29b_main();
    }
}
