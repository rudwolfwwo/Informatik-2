import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.GridLayout;

public class WhackNMoles extends JFrame {
    int disabledButtons = 0;
    public WhackNMoles(int buttons) {
        super("Whack " + buttons + " Moles!");
        JPanel panel = new JPanel(new GridLayout((buttons+2)/3,3));

        for (int i = 1; i <= buttons; i++) {
            JButton button = new JButton("" + i);
            panel.add(button);
            button.addActionListener(e -> {
                button.setEnabled(false);
                disabledButtons++;
                if (disabledButtons == buttons) dispose();
            });

        }
        this.add(panel);
        this.pack();
        this.setVisible(true);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    }
    public static void main(String[] args) {
        String s = JOptionPane.showInputDialog("Bitte Anzahl x an Buttons angeben!");
        try {
            int i = Integer.parseInt(s);
            if (i < 0) throw new IllegalArgumentException();
            new WhackNMoles(i);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Bitte nur positive ganze Zahlen!",
                    "Ungültige Eingabe", JOptionPane.ERROR_MESSAGE);
        }
    }
}
