import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class A23_24d_main {
    public static void main (String[] args) {
        Scanner input = new Scanner(System.in);
        input.useDelimiter(Pattern.compile("[\\r\\n]+"));

        try {
            String name;
            int nummer;
            for (int i = 0; i < 3; i++) {
                System.out.println("Bitte geben Sie einen " + (i + 1) + ". Namen ein: ");
                name = input.next();
                Student.check_Name(name);
                System.out.println("Bitte geben Sie die Matrikelnummer von " + name + " ein: ");
                nummer = input.nextInt();
                Student.check_Matrikelnummer(nummer);
                try {
                    new UniqueStudent(name, nummer);
                }  catch (DuplicateException e) {
                    System.err.println(e);
                }
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Ungueltige Eingabe: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.err.println("Für die Matrikelnummer sind nur Zahlen erlaubt");
        } finally {
            System.out.println("Gib nun eine Matrikelnummer ein!");
            System.out.println(UniqueStudent.ReturnStudent(input.nextInt()));
        }
    }
}
