import javax.swing.JOptionPane;

public class CountDown extends JOptionPane {
    public CountDown() {
        int i = Integer.parseInt(JOptionPane.showInputDialog("Bitte geben Sie ein natürliche Zahl ein!"));
        for (int j = i; j > 0; j--) {
            JOptionPane.showMessageDialog(this,"" + j);
        }
    }
    public static void main(String[] args) {
        new CountDown();
    }
}
