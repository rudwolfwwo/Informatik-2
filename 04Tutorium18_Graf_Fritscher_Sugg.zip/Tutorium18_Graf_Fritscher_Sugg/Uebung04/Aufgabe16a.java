import java.time.LocalDate;
import java.time.Period;

public class Aufgabe16a {
    public static void main (String[] args) {
        LocalDate now = LocalDate.now();
        LocalDate klausur = LocalDate.of(2023,8,1);
        Period zeitspanne = Period.between(now,klausur);
        System.out.println("Es verbleiben " + zeitspanne.getMonths() + " Monate und " + zeitspanne.getDays() + " Tage");
    }
}