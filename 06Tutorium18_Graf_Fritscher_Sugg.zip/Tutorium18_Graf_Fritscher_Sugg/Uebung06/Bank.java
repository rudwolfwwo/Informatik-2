import java.util.ArrayList;
import java.util.List;

public class Bank {
    private final List<BankAccount> allAccounts = new ArrayList<>();

    public void createBankAccount (String accountHolderName, String accountNumber) throws IllegalBankingException {
        for (BankAccount acc : allAccounts) {
            if (acc.getAccountNumber().equals(accountNumber)) {
                throw new IllegalBankingException("Given Account Number already exists");
            }
        }
        allAccounts.add(new BankAccount(accountHolderName, accountNumber));
    }
    public double getBalanceByHolder (String accountHolderName) {
        return allAccounts.stream()
                .filter(acc -> acc.getAccountHolderName().equals(accountHolderName))
                .mapToDouble(BankAccount::getBalance)
                .sum();
    }
    public void addBalance (String accountNumber, double difference) throws IllegalBankingException {
        if (Math.abs(difference) > 500) throw new IllegalBankingException("Difference must not be out of range +-500");
        boolean existingBankAccount = false;
        for (BankAccount acc : allAccounts) {
            if (acc.getAccountNumber().equals(accountNumber)) {
                acc.addBalance(difference);
                existingBankAccount = true;
                break;
            }
        }
        if (!existingBankAccount) throw new IllegalBankingException("No Account with given Account Number exists");
    }
}
