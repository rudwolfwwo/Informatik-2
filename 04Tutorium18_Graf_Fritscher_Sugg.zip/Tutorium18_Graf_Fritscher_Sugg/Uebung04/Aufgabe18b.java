import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Aufgabe18b {
    public static void main (String[] args) {
        HashMap<Integer,Integer> map = new HashMap<>();
        for (int i = 0; i < 10; i++) {
            map.put(i, 0);
        }
        for (int i = 0; i < 10; i++) {
            Random rdn = new Random();
            int zufallszahl = rdn.nextInt(0,10);
            map.put(zufallszahl,map.get(zufallszahl) + 1);
        }
        System.out.println("Die jeweiligen Häufigkeiten bei 10 Zufallszahlen sind: " + map +
                "\nDie durchschnittliche relative Abweichung ist: " + averageRelativeDeltaFromMean(map));

        while (averageRelativeDeltaFromMean(map) >= 0.01) {
            Random rdn = new Random();
            int zufallszahl = rdn.nextInt(0,10);
            map.put(zufallszahl,map.get(zufallszahl) + 1);
        }
        System.out.println("\nDie Anzahl der berechteten Zufallszahlen ist: " + map.values() +
                "\nDie durchschnittliche relative Abweichung ist: " + averageRelativeDeltaFromMean(map));
    }
    private static double averageRelativeDeltaFromMean(Map<Integer, Integer> map) {
        double durchschnitt = 0;
        for (int i = 0; i < map.size(); i++) {
            durchschnitt += map.get(i);
        }
        durchschnitt /= map.size();
        double abweichung = 0;
        for (int i = 0; i < map.size(); i++) {
            abweichung += Math.abs(map.get(i) - durchschnitt) /durchschnitt;
        }
        return abweichung / map.size();
    }
}
