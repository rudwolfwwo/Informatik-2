//Gehört nicht zur Abgabe, sonst kennt nur Java natürlich keinen BankAccount...

public class BankAccount {
    private String accountHolderName;
    private String accountNumber;
    private double balance = 0;
    public BankAccount(String accountHolderName, String accountNumber) {
        this.accountHolderName = accountHolderName;
        this.accountNumber = accountNumber;
    }

    private static boolean checkAccountHolderName(String accountHolderName) {
        return accountHolderName != null && accountHolderName.matches("[A-Z][a-z]*( [A-Z][a-z]*)*");
    }

    private static boolean checkAccountNumber(String accountNumber) {
        return accountNumber != null && accountNumber.matches("[A-Z\\d]{12}");
    }

    public String getAccountHolderName() {
        return this.accountHolderName;
    }
    public String getAccountNumber() {
        return this.accountNumber;
    }

    public double getBalance() {
        return this.balance;
    }
}
