import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Aufgabe17 {
    public static void main (String[] args) {
        Random rdn = new Random();
        ArrayList<String> myList = new ArrayList<>();

        for (int i = 0; i < 1000; i++) {
            myList.add(randomString (rdn.nextInt(3,8)));
        }
        if (myList.contains("ABC")) {
            System.out.println("\nDie Liste enthält \"ABC\"!");
        }
        Iterator<String> it = myList.iterator();
        int summe = 0;
        while (it.hasNext())
            summe += it.next().length();

        System.out.println(summe);

        for (String element : myList) {
            if (element.length() == 7) {
                System.out.print(element + ", ");
            }
        }
    }
    private static String randomString (int n) {
        Random rdn = new Random();
        String str = "";
        for (int i = 0; i < n; i++) {
            if (rdn.nextBoolean())
                str += (char) rdn.nextInt(65, 91);
            else
                str += (char) rdn.nextInt(97, 123);
        }
        return str;
    }
}
