import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class LabelCreatorListener {
    public LabelCreatorListener(JPanel panel) {
        Random rdn = new Random();
        JLabel label = new JLabel("" + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        label.setForeground(new Color(rdn.nextInt(255),rdn.nextInt(255),rdn.nextInt(255)));
        panel.add(label);
    }
}
