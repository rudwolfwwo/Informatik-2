package data;

import java.beans.PropertyChangeSupport;
import java.beans.PropertyChangeListener;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class BankAccountContainer implements Iterable<BankAccount>, Serializable {
    private static BankAccountContainer unique = null;
    private ArrayList<BankAccount> bankAccounts = new ArrayList<>();
    private PropertyChangeSupport changes = new PropertyChangeSupport(this);
    private BankAccountContainer() {

    }
    public static BankAccountContainer instance() {
        if (unique == null) {
            unique = new BankAccountContainer();
        }
        return unique;
    }
    public void linkBankAccount(BankAccount b) throws IllegalBankingException {
        if (!bankAccounts.contains(b)) {
            bankAccounts.add(b);
            changes.firePropertyChange("link",null, b);
        } else {
            throw new IllegalBankingException("Dieser Bankacccount wurde bereits hinzugefügt!");
        }
    }
    public void unlinkBankAccount(BankAccount b) throws IllegalBankingException {
        if (bankAccounts.contains(b)) {
            bankAccounts.remove(b);
            changes.firePropertyChange("unlink",b, null);
        } else {
            throw new IllegalBankingException("Dieser Bankacccount wurde noch nicht hinzugefügt!");
        }
    }

    public void addPropertyChangeListener(PropertyChangeListener l) {
        changes.addPropertyChangeListener(l);
    }
    public void removePropertyChangeListener(PropertyChangeListener l) {
        changes.removePropertyChangeListener(l);
    }

    @Override
    public Iterator<BankAccount> iterator() {
        return this.bankAccounts.iterator();
    }
}
