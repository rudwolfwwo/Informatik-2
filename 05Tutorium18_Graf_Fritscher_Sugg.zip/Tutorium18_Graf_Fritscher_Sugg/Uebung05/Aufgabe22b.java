import java.util.Random;
import java.util.function.IntSupplier;
import java.util.stream.IntStream;

public class Aufgabe22b {
    public static void main (String[] args) {
        Random rdn = new Random();

        IntSupplier intsuppe = () -> {
                int[] i = {2, 3, 5, 7};
                return i[rdn.nextInt(0,4)];};

        IntStream intstr = IntStream.generate(intsuppe).limit(100);
        System.out.println(intstr.reduce(Integer::sum).getAsInt());
    }
}
