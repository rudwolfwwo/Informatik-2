public class Aufgabe12a {
    public static void main (String[] args) {

        CharSequence[] ch = new CharSequence[args.length];
        System.arraycopy(args, 0, ch, 0, args.length);

        String matik = "matik";
        CharSequence str = matik;
        for (int i = 0; i < ch.length; i++) {
            if (ch[i].toString().contains(str)) {
                System.out.println("Die erste Postion von \"Matik\" im " + (i+1) + ". Kommandozeilenparameter ist " +
                        (ch[i].toString().indexOf(str.toString())+1));
            }
        }
    }
}