import java.time.LocalDate;

public class Aufgabe16b {
    public static void main(String[] args) {
        int laenge = LocalDate.now().lengthOfMonth() - LocalDate.now().getDayOfMonth();
        System.out.println("Bis zum Monatsende sind es noch " + laenge + " Tage!");
        int samstage = 0;
        int sonntage = 0;
        for (int i = 1; i < laenge + 1; i++) {
            switch (LocalDate.now().plusDays(i).getDayOfWeek()) {
                case SATURDAY -> samstage++;
                case SUNDAY -> sonntage++;
            }
        }
        System.out.println("Es verbleiben " + samstage + " Samstag(e) und " + sonntage + " Sonntag(e) in diesem Monat!");
    }
}