import javax.swing.JFrame;
import java.awt.BorderLayout;

public class LineFrame extends JFrame {
    public LineFrame() {
        super("Line Frame");
        this.add(new LinePanel(), BorderLayout.CENTER);
        this.setVisible(true);
        this.pack();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    public static void main(String[] args) {
        new LineFrame();
    }
}
