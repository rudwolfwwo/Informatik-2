import java.util.Arrays;
import java.util.Random;
import static java.util.Arrays.binarySearch;
import static java.util.Arrays.sort;

public class Aufgabe13b {
    public static void main (String[] args) {
        char[] ch = new char[30];
        Random rdn = new Random();

        for (int i = 0; i < ch.length; i++) {
            ch[i] = (char) (rdn.nextInt(65,91));
        }
        sort(ch);

        if (Arrays.toString(ch).contains("X")){
            System.out.println("Ein Vorkommen von 'X' ist an " + (binarySearch(ch,'X') + 1) + ". Stelle!");
        } else {
            System.out.println((binarySearch(ch,'X')*(-1) - 1) + " Buchstaben im Array sind lexikographisch kleiner als 'X'!");
        }
    }
}
