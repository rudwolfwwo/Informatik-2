import java.util.Arrays;
import java.util.Random;

import static java.util.Arrays.sort;
import static java.lang.Double.max;

public class Aufgabe14 {
    public static void main (String[] args) {
        double punkte = 0;
        for (int runde = 1; runde <= 5; runde++) {

            int[] wurf = wuerfeln();
            System.out.println("Der Wurf in der " + runde + ". Runde ist: \n\t\t" + Arrays.toString(wurf));

            //Maximale Punktzahl bei Augensumme je nach X
            double maxX = 0;
            for (int i : wurf) {
                if (maxX < augenSumme(wurf, i)) {
                    maxX = augenSumme(wurf, i);
                }
            }

            //Ausgabe der besten Option...
            double vergleich = max(max(maxX,fullHouse(wurf)),halbeChance(wurf));
            System.out.print("Die Option mit den meisten Punkten, nämlich stolzen " + vergleich + ", wird durch ");
            //...je nach Punktzahl
            String option = "die Augensumme der häufigsten Zahl";
            if (vergleich == fullHouse(wurf)) {
                option = "das Full House";
            }
            else if (vergleich == halbeChance(wurf)) {
                option = "die Hälfte der Augenzahlsumme";
            }
            System.out.println(option + " erreicht!\n\n");
            punkte += vergleich;
        }
        System.out.println("Die Gesamtpunktzahl beträgt damit: " + punkte);
    }
    static int[] wuerfeln() {
        Random rdn = new Random();
        int[] wurf = new int[5];
        for (int i = 0; i < wurf.length; i++) {
            wurf[i] = rdn.nextInt(1,7);
        }
        return wurf;
    }
    static double halbeChance(int[] wurf) {
        double summe = 0;
        for (int i = 0; i < wurf.length; i++) {
            summe += wurf[i];
        }
        return summe/2;
    }
    static double augenSumme(int[] wurf, int x) {
        int summe = 0;
        for (int i = 0; i < wurf.length; i++) {
            if (wurf[i] == x) {
                summe += x;
            }
        }
        return summe;
    }
    static double fullHouse(int[] wurf) {
        sort(wurf);
        if (wurf[0] == wurf[1] && wurf[4] == wurf[3] && (wurf[2] == wurf[3] || wurf[2] == wurf[1])) {
            return 25;
        }
        return 0;
    }
}
