import java.util.HashMap;

public class Aufgabe18a {
    public static void main (String[] args) {
        HashMap<Character, Integer> map = new HashMap<>();
        for (int i = 0; i < args.length; i++) {
            int freiesFeld = 0;
            for (int letter = 0; letter < args[i].length(); letter++) {
                int anzahl;
                if (map.containsKey(args[i].charAt(letter))) {
                    anzahl = map.get(args[i].charAt(letter)) + 1;
                } else {
                    anzahl = 1;
                }
                map.put(args[i].charAt(letter),anzahl);
            }
        }
        map.forEach((k, v) -> System.out.println("Das Zeichen \"" + k + "\" kam " + v + " Mal vor!"));
    }
}
