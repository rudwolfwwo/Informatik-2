public class DuplicateException extends Exception {
    public DuplicateException (String Attribute, String Value) {
        super(Attribute + " already taken: " + Value);
    }
}
