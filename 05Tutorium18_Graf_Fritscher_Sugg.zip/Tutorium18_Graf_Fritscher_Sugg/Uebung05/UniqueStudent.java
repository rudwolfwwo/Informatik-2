import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UniqueStudent extends Student {

    private static HashMap<Integer,String> usedNumbers = new HashMap();
    public UniqueStudent(String name, int nummer) throws DuplicateException {
        super(name, nummer);
        if (usedNumbers.containsKey(nummer)) {
            throw new DuplicateException("" + nummer, name);
        } else {
            usedNumbers.put(nummer, name);
        }
    }
    public static String ReturnStudent (int nummer) {
        if (usedNumbers.containsKey(nummer)) {
            return "(" + nummer + ", " + usedNumbers.get(nummer) + ")";
        }
        return null;
    }
}
