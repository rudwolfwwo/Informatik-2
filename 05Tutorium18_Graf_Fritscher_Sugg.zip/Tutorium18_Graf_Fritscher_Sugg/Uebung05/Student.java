import static java.lang.Character.isLowerCase;
public class Student {
    private String name;
    private int nummer;
    public Student(String name, int nummer) {
        set_Name(name);
        set_Matrikelnummer(nummer);
    }
    private void set_Name (String name) {
        if (check_Name(name)) this.name = name;
    }
    private void set_Matrikelnummer (int nummer) {
        if (check_Matrikelnummer(nummer)) this.nummer = nummer;
    }
    public static boolean check_Name (String name) throws IllegalArgumentException {
        if (name == null || isLowerCase(name.charAt(0)))
            throw new IllegalArgumentException("Der Name darf nicht leer sein und muss groß anfangen!");
        else
            return true;
    }
    public static boolean check_Matrikelnummer (int nummer) throws IllegalArgumentException {
        if (1000000 <= nummer && nummer <= 9999999) {
            return true;
        }
        else {
            throw new IllegalArgumentException("Die Matrikelnummer muss siebenstellig sein!");
        }
    }

    @Override
    public String toString() {
        return "(" + nummer + ", " + name + ")";
    }
}
