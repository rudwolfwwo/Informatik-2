import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;

public class TestFrame extends JFrame {
    JButton closeButton =  new JButton();
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().getClass().isInstance(JButton.class)) {
            JButton b = (JButton) e.getSource();
            if (closeButton.equals(b)) {
                JOptionPane.showMessageDialog(this,"exciting...");
                dispose();
            }
        }
    }
}
