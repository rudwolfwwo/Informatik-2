public class Aufgabe12b {
    public static void main (String[] args) {
        String str = "ich.bin.ein.String";
        StringBuffer strBuffer = new StringBuffer("ich.bin.ein.StringBuffer");
        StringBuilder strBuilder = new StringBuilder("ich.bin.ein.StringBuider");

        System.out.println(extractDataTyp(str) + "\n" + extractDataTyp(strBuffer) + "\n" + extractDataTyp(strBuilder));
    }
    public static CharSequence extractDataTyp (CharSequence ch) {
        try {
            return ch.subSequence(ch.toString().lastIndexOf("."),ch.length());
        } catch (Exception EnthaeltkeinenPunkt) {
            return "";
        }
    }
}
