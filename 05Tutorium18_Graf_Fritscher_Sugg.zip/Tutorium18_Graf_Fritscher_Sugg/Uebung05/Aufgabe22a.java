import java.util.Random;
import java.util.stream.IntStream;

public class Aufgabe22a {
    public static void main (String[] args) {
        Random rdn = new Random();
        IntStream intstr = rdn.ints(1000, 0, 100);
        System.out.println(intstr.map(i -> i/10).distinct().sum());
    }
}