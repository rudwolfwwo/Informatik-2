import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class DontMinimizeMe extends JFrame {
    public DontMinimizeMe() {
        super("Don't minimize me!");
        this.setSize(400,100);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(0,3));
        this.add(panel, BorderLayout.CENTER);

        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowIconified(WindowEvent e) {
                panel.add(new JButton("ouch"));
            }
            @Override
            public void windowDeiconified(WindowEvent e) {
                if (panel.getComponentCount() > 3) {
                    if (panel.getComponentCount() > 6) {
                        setTitle("Dude, seriously, stop");
                    } else {
                        setTitle("Stop iconifying me");
                    }
                }
            }
        });
        this.setVisible(true);
    }
    public static void main(String[] args) {
        new DontMinimizeMe();
    }
}
