import javax.swing.JFrame;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;
import java.awt.Graphics;

public class MouseHighlighter extends JFrame{

    int x = -1;
    int y = -1;
    public MouseHighlighter() {
        super("Mouse Highlighter");
        this.setSize(300,300);

        this.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                x = e.getX();
                y = e.getY();
                repaint();
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                mouseMoved(e);
            }
        });

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.drawOval(x-7,y-7,15,15);
    }

    public static void main(String[] args) {
        new MouseHighlighter();
    }
}
