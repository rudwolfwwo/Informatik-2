import java.awt.Point;
import java.util.ArrayList;

public class PointCloud {
    private int limit = 0;
    private ArrayList<Point> points = new ArrayList<>();
    public void addPoint(Point p) {
        double radius = Math.sqrt(Math.pow(p.getX(),2) + Math.pow(p.getY(),2));
        if (radius > this.limit) {
            throw new IllegalArgumentException("Point to far away from cloud");
        }
        points.add(p);
    }
}