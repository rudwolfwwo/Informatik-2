import java.time.LocalDate;
import java.util.regex.Pattern;

public class BankAccount {
    private String accountHolderName;
    private final String accountNumber;
    private final LocalDate openingDate;
    private double balance;

    public BankAccount (String accountHolderName, String accountNumber) {
        if (checkKontonummer(accountNumber)) {
            this.accountNumber = accountNumber;
        } else {
            throw new IllegalArgumentException("Invalid Account Number");
        }
        setaccountHolderName(accountHolderName);
        this.openingDate = LocalDate.now();
        this.balance = 0;
    }

    public void addBalance (double difference) {
        balance += difference;
    }
    public void setaccountHolderName (String accountHolderName) {
        if (checkAccountHolderName(accountHolderName)) {
            this.accountHolderName = accountHolderName;
        } else {
            throw new IllegalArgumentException("Invalid Account Holdername");
        }
    }

    public String getAccountHolderName () {
        return accountHolderName;
    }
    public String getAccountNumber() {
        return accountNumber;
    }
    public LocalDate getOpeningDate() {
        return openingDate;
    }
    public double getBalance() {
        return balance;
    }


    private boolean checkAccountHolderName (String accountHolderName) {
        return Pattern.matches("[A-Z][a-z]*([\\s][A-Z][a-z]*)*", accountHolderName);
    }
    private boolean checkKontonummer (String accountNumber) {
        return (Pattern.matches("([A-Z]||[\\d]){12}", accountNumber));
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) return false;
        if (!o.getClass().equals(this.getClass())) return false;
        return (accountNumber.equals(((BankAccount) o).getAccountNumber()));
    }

    @Override
    public String toString() {
            return "Bankkonto von " + this.getAccountHolderName() + " mit Kontonummer "
                + this.getAccountNumber() + ", mit aktuell " + this.getBalance()
                + " Euro, wurde am " + this.getOpeningDate() + " eroeffnet.";
    }
}
