import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

public class Aufgabe19b {
    public static void main (String[] args) {
        Random rdn = new Random();
        List<Integer> liste = new ArrayList<> ();
        new Random().ints(0,10000).limit(5000).forEach(liste::add);
        liste.replaceAll(i -> (i % 2 == 0) ? i*i : i);

        Predicate<Integer> isPrim = (prim -> {
            for (int i = 2; i < prim; i++) {
                if (prim % i == 0) return false;
            }
            return true;
        });
        liste.stream().filter(i -> !isPrim.test(i)).forEach(System.out::println);
    }
}
