package gui;


import data.BankAccount;
import data.BankAccountContainer;
import data.IllegalBankingException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import java.util.Vector;

import static javax.swing.JOptionPane.ERROR_MESSAGE;

public class ListBankAccounts extends JDialog implements ActionListener, PropertyChangeListener {
    private BankAccountContainer bankAccountContainer;
    private JList<BankAccount> bankAccountList;

    public ListBankAccounts(BankGUI parent) {
        super(parent, "Show all bank accounts", false);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        JLabel lblAllBankAccounts = new JLabel("All bank accounts: ");
        add(lblAllBankAccounts, BorderLayout.NORTH);
        bankAccountList = new JList<>();
        add(bankAccountList, BorderLayout.CENTER);

        JPanel buttons = new JPanel();
        add(buttons, BorderLayout.SOUTH);
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener(this);
        buttons.add(cancel);
        JButton delete = new JButton("Delete bank account");
        delete.addActionListener(this);
        buttons.add(delete);
        JButton edit = new JButton("Edit bank account");
        edit.addActionListener(this);
        buttons.add(edit);

        setLocation(parent.getLocation().x + 200, parent.getLocation().y + 200);

        bankAccountContainer = BankAccountContainer.instance();
        bankAccountContainer.addPropertyChangeListener(this);
        for (BankAccount b : bankAccountContainer) {
            b.addPropertyChangeListener(this);
        }
        updateList();
        pack();
        setVisible(true);
    }

    @Override
    public void propertyChange(PropertyChangeEvent e) {
        if (e.getPropertyName().equals("link")) {
            bankAccountContainer.addPropertyChangeListener(this);
        }
        if (e.getPropertyName().equals("unlink")) {
            bankAccountContainer.removePropertyChangeListener(this);
        }
        updateList();
    }

    private void updateList() {
        Vector<BankAccount> v = new Vector<BankAccount>();
        for (BankAccount b : bankAccountContainer)
            v.add(b);
        bankAccountList.setListData(v);
        pack();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Delete bank account")) {
            onDelete();
        } else if (e.getActionCommand().equals("Cancel")) {
            onCancel();
        } else if (e.getActionCommand().equals("Edit bank account")) {
            onEdit();
        }
    }

    private void onDelete() {
        BankAccount temp = bankAccountList.getSelectedValue();
        if (temp == null) {
            JOptionPane.showMessageDialog(this,
                    "Es wurde kein Bankaccount ausgewählt!","Fehler",
                    ERROR_MESSAGE);
        } else {
            try {
                bankAccountContainer.unlinkBankAccount(temp);
            } catch (IllegalBankingException e) {
                System.err.println("Illegal Programm State");
            }
            updateList();
        }
    }

    private void onEdit() {
        BankAccount temp = bankAccountList.getSelectedValue();
        if (temp == null) {
            JOptionPane.showMessageDialog(this,
                    "Es wurde kein Bankaccount ausgewählt!","Fehler",
                    ERROR_MESSAGE);
        } else {
            new ChangeBankAccount(this, temp);
        }
    }

    private void onCancel() {
        dispose();
    }
}
