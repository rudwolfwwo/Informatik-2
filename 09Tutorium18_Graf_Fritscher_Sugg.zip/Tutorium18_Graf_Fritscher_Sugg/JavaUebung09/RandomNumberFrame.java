import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.util.Random;

public class RandomNumberFrame extends JFrame {
    public RandomNumberFrame(Integer n) {
        super("Random Number Frame");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(new GridLayout(0,3));
        Random rng = new Random();
        for (int i = 0; i < n; i++) {
            this.add(new JLabel("Current time: " + String.valueOf(rng.nextInt(100))));
        }
        this.pack();
        this.setVisible(true);
    }
    public static void main(String[] args) {
        new RandomNumberFrame(10);
    }
}