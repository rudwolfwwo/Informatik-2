public class Match {
    private Team team1, team2, winner;

    public Match(Team team1, Team team2, Team winner) {
        if (!team1.equals(team2) && (team1 == winner || team2 == winner)) {
            this.team1 = team1;
            this.team2 = team2;
            this.winner = winner;
        }
    }
}
